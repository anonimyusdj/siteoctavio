<?php
  define('HOST', 'localhost');
  define('DBNAME','siteOctavio');
  define('DBUSER','anonimyusdj');
  define('DBPASS','anonimyusdj');
  define('DBPORT', '3306');
  define('DBCHARSET', 'utf8');

?>
