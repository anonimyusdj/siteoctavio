<?php
  require_once "conf.php";
  //require_once "config.php";
  require_once "serv.php";
  require_once "../model_PHP/config.php";
  require_once "../model_PHP/albums_model.php";
?>
