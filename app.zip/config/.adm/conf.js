var app=angular.module("adm",["ngRoute","ngImageInputWithPreview"]);
///////////////////factory///////////////////////
app.factory("admin",function($http){
  var service={};
  var urlBase="../app/server/php/"
  service.getConfig=function(){
    return $http.get(urlBase+"config.php",{params:{
      "table":"config",
      "opcion":"config"}})
  }
  service.getBackaground=function(){
    return $http.get("../octavio/background.json")
  }
//  service.background="";
  return service;
});
app.factory("variables",function(){
  return {
    background:""
  }
});

app.service('upload', ["$http", "$q", function ($http, $q)
{
	this.uploadFile = function(file, name)
	{
		var deferred = $q.defer();
		var formData = new FormData();
		formData.append("name", name);
		formData.append("file", file);
		return $http.post("../app/server/php/config.php", formData, {
			headers: {
				"Content-type": undefined
			},
			transformRequest: angular.identity
		})
		.success(function(res)
		{
			deferred.resolve(res);
		})
		.error(function(msg, code)
		{
			deferred.reject(msg);
		})
		return deferred.promise;
	}
}]);
////////////////////////////////////////////////

//////////////////ng-Route/////////////////////
app.config(function($routeProvider){
  $routeProvider.when("/",{
    templateUrl: "view/home.html"
  })
.when("/music",{
  templateUrl:"app/public/view/musica.html",
  controller:"musica"
})
.when("/octavio",{
  templateUrl:"app/public/view/login.html",
  controller:"login"
})
.when("/albums",{
  templateUrl:"view/albums.html",
  controller:"albums"
})
  //.otherwise({redirectTo: "/" });
});
//////////////////////////////////////////////

///////////////directive/////////////////////
app.directive("menu",function(){
  return{
    restrict:'E',
    templateUrl:"view/menu.html"
  }
});

app.directive("pie",function(){
  return{
    restrict:'E',
    templateUrl:"view/footer.html"
  }
});

app.directive("side",function(){
  return{
    restrict:'E',
    templateUrl:"view/side.html"
  }
});
app.directive('uploaderModel', ["$parse", function ($parse) {
	return {
		restrict: 'A',
		link: function (scope, iElement, iAttrs)
		{
			iElement.on("change", function(e)
			{
				$parse(iAttrs.uploaderModel).assign(scope, iElement[0].files[0]);
			});
		}
	};
}])


//////////////controller//////////////////////
app.controller("homeController",function($scope, admin,$http,upload){
    $scope.saludo="Sitio de Musica de Octavio Vasquez";
    //$scope.bg=admin.background;
    var urlBase="../app/server/php/config.php";

    admin.getConfig().then(function(response){
      //console.log(response.data.resultado[0]);
      $scope.adm=response.data.resultado[0];
      //console.log($scope.color.background);
    });
    admin.getBackaground().then(function(response){
      $scope.background=response.data.background;
    //  console.log($scope.background);
    });
    $scope.guardarBG=function(bg){
      $http.get(urlBase,{params:{
        "table":"config",
        "opcion":"background",
        "bg":bg
      }}).then(function(response){
        //console.log(bg);
        alert(response.data.resultado);
        location.reload()
      });
    };
    $scope.uploadFile = function()
    {
      var name = $scope.name;
      var file = $scope.file;

      upload.uploadFile(file, name).then(function(res)
      {
        console.log(res);
      })
    }
});

app.controller("albums",function($scope,$http,admin){

});
