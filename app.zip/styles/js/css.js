$(document).ready(function(){
   $('.sidenav').sidenav();
 });

 $(document).ready(function(){
   $('.carousel').carousel();
 });

 $(document).ready(function() {
    $('input#input_text, textarea#textarea2').characterCounter();
  });

  $(document).ready(function(){
     $('.tooltipped').tooltip();
   });

   $(document).ready(function(){
        $('.dropdown-trigger').dropdown();
    });

$(document).ready(function(){
        $('.collapsible').collapsible();
      });
$(document).ready(function(){
         $('select').formSelect();
});
